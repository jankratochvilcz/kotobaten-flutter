// src/lib/cards.ts
function nullableNumber(value) {
  if (value == null) {
    return null;
  }
  if (typeof value !== "number" || Number.isNaN(value)) {
    return null;
  }
  return value;
}
function nullableString(value) {
  if (typeof value !== "string") {
    return null;
  }
  const trimmed = value.trim();
  return trimmed.length === 0 ? null : trimmed;
}
function toReaderCard(value) {
  if (value == null || typeof value !== "object") {
    return null;
  }
  const card = value;
  if (typeof card.id !== "string" || card.id.length === 0) {
    return null;
  }
  if (card.type !== "Word" && card.type !== "Grammar") {
    return null;
  }
  if (typeof card.sense !== "string") {
    return null;
  }
  return {
    id: card.id,
    type: card.type,
    sense: card.sense,
    kana: nullableString(card.kana),
    kanji: nullableString(card.kanji),
    senseRetention: nullableNumber(card.senseRetention),
    kanaRetention: nullableNumber(card.kanaRetention)
  };
}
function toDictionaryEntry(value) {
  if (value == null || typeof value !== "object") {
    return null;
  }
  const entry = value;
  const senses = Array.isArray(entry.senses) ? entry.senses.flatMap((sense) => {
    if (sense == null || typeof sense !== "object") {
      return [];
    }
    const row = sense;
    return [
      {
        senses: Array.isArray(row.senses) ? row.senses.filter(
          (item) => typeof item === "string"
        ) : [],
        partsOfSpeech: Array.isArray(row.partsOfSpeech) ? row.partsOfSpeech.filter(
          (item) => typeof item === "string"
        ) : [],
        isSuruVerb: row.isSuruVerb === true
      }
    ];
  }) : [];
  return {
    kanji: typeof entry.kanji === "string" ? entry.kanji : "",
    kana: typeof entry.kana === "string" ? entry.kana : "",
    isCommon: entry.isCommon === true,
    senses
  };
}
function parseApiError(status, body) {
  if (body != null && typeof body === "object" && "message" in body) {
    const message = body.message;
    if (typeof message === "string" && message.trim().length > 0) {
      return message;
    }
    if (Array.isArray(message)) {
      const text = message.filter((item) => typeof item === "string").join(", ");
      if (text.length > 0) {
        return text;
      }
    }
  }
  if (status === 401 || status === 403) {
    return "Sign in again to use Kotobaten.";
  }
  if (status === 503) {
    return "Kotobaten API is unavailable right now.";
  }
  return `Kotobaten API returned ${status}.`;
}
function emailFromAccessToken(token) {
  const parts = token.split(".");
  if (parts.length < 2) {
    return null;
  }
  try {
    const padded = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const json = atob(
      padded.padEnd(padded.length + (4 - padded.length % 4) % 4, "=")
    );
    const payload = JSON.parse(json);
    return typeof payload.email === "string" ? payload.email : null;
  } catch {
    return null;
  }
}

// src/lib/session.ts
var REFRESH_LEEWAY_MS = 6e4;
function usableAccessToken(session, now, refreshed) {
  if (session.expiresAt > now + REFRESH_LEEWAY_MS) {
    return session.accessToken;
  }
  if (refreshed) {
    return refreshed.accessToken;
  }
  return session.expiresAt > now ? session.accessToken : null;
}
function claimLoginState(claimed, state) {
  if (!state || claimed.has(state)) {
    return false;
  }
  claimed.add(state);
  return true;
}
function extensionOwnsLoginState(pendingState, claimedStates, incomingState) {
  return pendingState === incomingState || claimedStates.includes(incomingState);
}
function sessionAfterHarvest(existing, harvested) {
  if (existing && existing.expiresAt >= harvested.expiresAt) {
    return null;
  }
  return {
    accessToken: harvested.accessToken,
    expiresAt: harvested.expiresAt,
    ...existing?.refreshToken ? { refreshToken: existing.refreshToken } : {}
  };
}

// src/messages.ts
var API_BASE_URL_DEFAULT = "https://kotobaten-api.fly.dev";
var AUTH0_DOMAIN = "kotobaten.eu.auth0.com";
var AUTH0_CLIENT_ID = "zIO0e4yl1e7E3BMl4rmD1Ymo2CM6g3JV";
var AUTH0_AUDIENCE = "https://kotobaten.app/api";
var AUTH0_REDIRECT_URI = "https://web.kotobaten.app";
var PENDING_LOGIN_KEY = "kotobaten.pendingLogin";
var CLAIMED_LOGIN_STATES_KEY = "kotobaten.claimedLoginStates";
var DEFAULT_SETTINGS = {
  apiBaseUrl: API_BASE_URL_DEFAULT,
  readingEnabled: false,
  manualToken: "",
  previewSample: false,
  sidebarPinned: false
};
function normalizeApiBaseUrl(input) {
  const trimmed = input.trim();
  if (trimmed.length === 0) {
    throw new Error("API URL is required.");
  }
  let url;
  try {
    url = new URL(trimmed);
  } catch {
    throw new Error("API URL must be a full http or https address.");
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") {
    throw new Error("API URL must start with https:// or http://.");
  }
  return url.origin;
}

// src/background.ts
var SETTINGS_KEY = "kotobaten.settings";
var SESSION_KEY = "kotobaten.session";
var COLLECTION_KEY = "kotobaten.collection";
var LOGIN_ERROR_KEY = "kotobaten.loginError";
var COLLECTION_MAX_AGE_MS = 10 * 60 * 1e3;
var CARD_PAGE_SIZE = 200;
var CARD_PAGE_CAP = 40;
async function readPendingLogin() {
  const stored = await chrome.storage.session.get(PENDING_LOGIN_KEY);
  const value = stored[PENDING_LOGIN_KEY];
  if (!value || typeof value.verifier !== "string" || typeof value.state !== "string" || typeof value.tabId !== "number") {
    return null;
  }
  return value;
}
async function writePendingLogin(pending) {
  if (pending == null) {
    await chrome.storage.session.remove(PENDING_LOGIN_KEY);
    return;
  }
  await chrome.storage.session.set({ [PENDING_LOGIN_KEY]: pending });
}
function bytesToBase64Url(bytes) {
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function randomUrlToken(byteLength) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return bytesToBase64Url(bytes);
}
async function sha256Base64Url(value) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value)
  );
  return bytesToBase64Url(new Uint8Array(digest));
}
async function readSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  const value = stored[SETTINGS_KEY];
  return {
    apiBaseUrl: typeof value?.apiBaseUrl === "string" && value.apiBaseUrl.length > 0 ? value.apiBaseUrl : DEFAULT_SETTINGS.apiBaseUrl,
    readingEnabled: value?.readingEnabled === true,
    manualToken: typeof value?.manualToken === "string" ? value.manualToken : "",
    previewSample: value?.previewSample === true,
    sidebarPinned: value?.sidebarPinned === true
  };
}
async function writeSettings(settings) {
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
}
async function readSession() {
  const stored = await chrome.storage.local.get(SESSION_KEY);
  const value = stored[SESSION_KEY];
  if (!value || typeof value.accessToken !== "string" || value.accessToken.length === 0) {
    return null;
  }
  return value;
}
async function writeSession(session) {
  if (session == null) {
    await chrome.storage.local.remove(SESSION_KEY);
    return;
  }
  await chrome.storage.local.set({ [SESSION_KEY]: session });
}
function tokenFingerprint(token) {
  return `${token.slice(0, 12)}:${token.length}`;
}
async function clearCollection() {
  await chrome.storage.local.remove(COLLECTION_KEY);
}
async function broadcast(message) {
  const tabs = await chrome.tabs.query({});
  await Promise.all(
    tabs.map(async (tab) => {
      if (tab.id == null) {
        return;
      }
      try {
        await chrome.tabs.sendMessage(tab.id, message);
      } catch {
      }
    })
  );
}
async function refreshSession(session) {
  if (!session.refreshToken) {
    return null;
  }
  const response = await fetch(`https://${AUTH0_DOMAIN}/oauth/token`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      grant_type: "refresh_token",
      client_id: AUTH0_CLIENT_ID,
      refresh_token: session.refreshToken
    })
  });
  if (!response.ok) {
    return null;
  }
  const body = await response.json();
  if (typeof body.access_token !== "string") {
    return null;
  }
  const next = {
    accessToken: body.access_token,
    refreshToken: body.refresh_token ?? session.refreshToken,
    expiresAt: Date.now() + (body.expires_in ?? 3600) * 1e3
  };
  await writeSession(next);
  return next;
}
async function currentAccessToken() {
  const settings = await readSettings();
  const manual = settings.manualToken.trim();
  if (manual.length > 0) {
    return manual;
  }
  const session = await readSession();
  if (!session) {
    return null;
  }
  const now = Date.now();
  const refreshed = session.expiresAt <= now + 6e4 ? await refreshSession(session) : null;
  return usableAccessToken(session, now, refreshed);
}
async function readLoginError() {
  const stored = await chrome.storage.session.get(LOGIN_ERROR_KEY);
  const value = stored[LOGIN_ERROR_KEY];
  return typeof value === "string" && value.length > 0 ? value : null;
}
async function sessionView() {
  const settings = await readSettings();
  const loginError = await readLoginError();
  const manual = settings.manualToken.trim();
  if (manual.length > 0) {
    return {
      signedIn: true,
      expiresAt: null,
      email: emailFromAccessToken(manual),
      manual: true,
      loginError
    };
  }
  const session = await readSession();
  if (!session || session.expiresAt <= Date.now()) {
    return {
      signedIn: false,
      expiresAt: null,
      email: null,
      manual: false,
      loginError
    };
  }
  return {
    signedIn: true,
    expiresAt: session.expiresAt,
    email: emailFromAccessToken(session.accessToken),
    manual: false,
    loginError
  };
}
async function apiFetch(path, init = {}) {
  const settings = await readSettings();
  const token = await currentAccessToken();
  if (!token) {
    throw new Error("Sign in to Kotobaten to use reading help.");
  }
  const url = new URL(path, settings.apiBaseUrl);
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bearer ${token}`);
  return fetch(url, { ...init, headers, signal: AbortSignal.timeout(2e4) });
}
async function readJson(response) {
  const text = await response.text();
  if (text.length === 0) {
    return null;
  }
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
async function fetchAllCards() {
  const cards = [];
  for (let page = 0; page < CARD_PAGE_CAP; page += 1) {
    const response = await apiFetch(
      `/cards?page=${page}&pageSize=${CARD_PAGE_SIZE}`
    );
    const body = await readJson(response);
    if (!response.ok) {
      throw new Error(parseApiError(response.status, body));
    }
    const pageBody = body;
    const rows = Array.isArray(pageBody.cards) ? pageBody.cards : [];
    for (const row of rows) {
      const card = toReaderCard(row);
      if (card) {
        cards.push(card);
      }
    }
    if (pageBody.hasMoreCards !== true) {
      break;
    }
  }
  return cards;
}
async function getCollection(force) {
  const token = await currentAccessToken();
  if (!token) {
    return {
      cards: [],
      fetchedAt: null,
      error: "Sign in to Kotobaten to underline words from your collection."
    };
  }
  const fingerprint = tokenFingerprint(token);
  if (!force) {
    const stored = await chrome.storage.local.get(COLLECTION_KEY);
    const cached = stored[COLLECTION_KEY];
    if (cached && cached.tokenFingerprint === fingerprint && Date.now() - cached.fetchedAt < COLLECTION_MAX_AGE_MS && Array.isArray(cached.cards)) {
      return { cards: cached.cards, fetchedAt: cached.fetchedAt, error: null };
    }
  }
  try {
    const cards = await fetchAllCards();
    const fetchedAt = Date.now();
    const snapshot = {
      cards,
      fetchedAt,
      tokenFingerprint: fingerprint
    };
    await chrome.storage.local.set({ [COLLECTION_KEY]: snapshot });
    return { cards, fetchedAt, error: null };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not load your collection.";
    return { cards: [], fetchedAt: null, error: message };
  }
}
async function search(term) {
  const response = await apiFetch(`/search?term=${encodeURIComponent(term)}`);
  const body = await readJson(response);
  if (!response.ok) {
    throw new Error(parseApiError(response.status, body));
  }
  const payload = body;
  return {
    query: typeof payload.query === "string" ? payload.query : term,
    cards: Array.isArray(payload.cards) ? payload.cards.flatMap((row) => {
      const card = toReaderCard(row);
      return card ? [card] : [];
    }) : [],
    dictionaryCards: Array.isArray(payload.dictionaryCards) ? payload.dictionaryCards.flatMap((row) => {
      const entry = toDictionaryEntry(row);
      return entry ? [entry] : [];
    }) : []
  };
}
async function translate(text) {
  const params = new URLSearchParams({ text, to: "en" });
  const response = await apiFetch(`/translate?${params.toString()}`);
  const body = await readJson(response);
  if (!response.ok) {
    throw new Error(parseApiError(response.status, body));
  }
  const translation = body.translation;
  if (typeof translation !== "string") {
    throw new Error("Translation came back empty.");
  }
  return { translation };
}
async function addCard(input) {
  const response = await apiFetch("/cards", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      sense: input.sense,
      kanji: input.kanji || void 0,
      kana: input.kana || void 0,
      note: input.note || void 0,
      type: "Word"
    })
  });
  const body = await readJson(response);
  if (!response.ok) {
    throw new Error(parseApiError(response.status, body));
  }
  const card = toReaderCard(body);
  if (!card) {
    throw new Error(
      "Kotobaten created the card, but the response was unreadable."
    );
  }
  await clearCollection();
  return card;
}
async function testConnection() {
  const response = await apiFetch("/user");
  const body = await readJson(response);
  if (!response.ok) {
    throw new Error(parseApiError(response.status, body));
  }
  return "Connected to Kotobaten.";
}
async function startLogin() {
  const previous = await readPendingLogin();
  if (previous) {
    try {
      await chrome.tabs.remove(previous.tabId);
    } catch {
    }
    await writePendingLogin(null);
  }
  const verifier = randomUrlToken(48);
  const challenge = await sha256Base64Url(verifier);
  const state = randomUrlToken(16);
  const url = new URL(`https://${AUTH0_DOMAIN}/authorize`);
  url.search = new URLSearchParams({
    response_type: "code",
    client_id: AUTH0_CLIENT_ID,
    redirect_uri: AUTH0_REDIRECT_URI,
    audience: AUTH0_AUDIENCE,
    scope: "openid profile email offline_access",
    code_challenge: challenge,
    code_challenge_method: "S256",
    state
  }).toString();
  const tab = await chrome.tabs.create({ url: url.toString() });
  if (tab.id == null) {
    throw new Error("Could not open the Kotobaten sign-in tab.");
  }
  await writePendingLogin({ verifier, state, tabId: tab.id });
}
async function exchangeCode(code, verifier) {
  const response = await fetch(`https://${AUTH0_DOMAIN}/oauth/token`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      grant_type: "authorization_code",
      client_id: AUTH0_CLIENT_ID,
      code,
      code_verifier: verifier,
      redirect_uri: AUTH0_REDIRECT_URI
    })
  });
  const body = await response.json();
  if (!response.ok || typeof body.access_token !== "string") {
    throw new Error(
      body.error_description || "Kotobaten sign-in did not finish."
    );
  }
  await writeSession({
    accessToken: body.access_token,
    refreshToken: body.refresh_token,
    expiresAt: Date.now() + (body.expires_in ?? 3600) * 1e3
  });
  await chrome.storage.session.remove(LOGIN_ERROR_KEY);
  await clearCollection();
  await broadcast({ type: "session-changed" });
}
var claimedLoginStates = /* @__PURE__ */ new Set();
async function readClaimedLoginStates() {
  const stored = await chrome.storage.session.get(CLAIMED_LOGIN_STATES_KEY);
  const value = stored[CLAIMED_LOGIN_STATES_KEY];
  if (!Array.isArray(value)) {
    return [];
  }
  return value.filter((state) => typeof state === "string");
}
async function rememberClaimedLoginState(state) {
  const states = await readClaimedLoginStates();
  if (states.includes(state)) {
    return;
  }
  await chrome.storage.session.set({
    [CLAIMED_LOGIN_STATES_KEY]: [...states, state].slice(-20)
  });
}
function forgetClaimedLoginState(state) {
  void readClaimedLoginStates().then((states) => {
    const next = states.filter((item) => item !== state);
    return chrome.storage.session.set({ [CLAIMED_LOGIN_STATES_KEY]: next });
  });
}
async function finishLogin(code, state, error, known) {
  if (!claimLoginState(claimedLoginStates, state)) {
    return;
  }
  let owned = false;
  try {
    const pending = known ?? await readPendingLogin();
    if (!pending || state !== pending.state) {
      if (state) {
        claimedLoginStates.delete(state);
      }
      return;
    }
    await rememberClaimedLoginState(state);
    await writePendingLogin(null);
    owned = true;
    if (!code || error) {
      await chrome.storage.session.set({
        [LOGIN_ERROR_KEY]: error || "Kotobaten sign-in did not finish."
      });
      await broadcast({ type: "session-changed" });
      return;
    }
    await exchangeCode(code, pending.verifier);
  } catch (exchangeError) {
    if (state && !owned) {
      claimedLoginStates.delete(state);
      forgetClaimedLoginState(state);
    } else if (owned) {
      const text = exchangeError instanceof Error ? exchangeError.message : "Kotobaten sign-in did not finish.";
      await chrome.storage.session.set({ [LOGIN_ERROR_KEY]: text });
      await broadcast({ type: "session-changed" });
    }
    throw exchangeError;
  }
}
async function captureLoginRedirect(tabId, url) {
  const pending = await readPendingLogin();
  if (!pending) {
    return;
  }
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return;
  }
  if (parsed.origin !== AUTH0_REDIRECT_URI) {
    return;
  }
  const code = parsed.searchParams.get("code");
  const state = parsed.searchParams.get("state");
  const error = parsed.searchParams.get("error_description") || parsed.searchParams.get("error");
  if (!code && !error || state !== pending.state) {
    return;
  }
  try {
    await finishLogin(code, state, error, pending);
  } finally {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
    }
  }
}
async function handle(message, sender) {
  switch (message.type) {
    case "get-settings":
      return { ok: true, data: await readSettings() };
    case "save-settings": {
      const apiBaseUrl = normalizeApiBaseUrl(message.apiBaseUrl);
      const settings = await readSettings();
      const next = {
        ...settings,
        apiBaseUrl,
        manualToken: message.manualToken.trim(),
        previewSample: settings.previewSample
      };
      await writeSettings(next);
      await clearCollection();
      await broadcast({ type: "session-changed" });
      return { ok: true, data: next };
    }
    case "get-session":
      return { ok: true, data: await sessionView() };
    case "sign-in":
      await startLogin();
      return { ok: true, data: null };
    case "sign-out":
      await writeSession(null);
      await chrome.storage.session.remove(LOGIN_ERROR_KEY);
      await clearCollection();
      await broadcast({ type: "session-changed" });
      return { ok: true, data: await sessionView() };
    case "set-reading": {
      const settings = await readSettings();
      const next = { ...settings, readingEnabled: message.enabled };
      await writeSettings(next);
      await broadcast({ type: "reading-changed", enabled: message.enabled });
      return { ok: true, data: next };
    }
    case "set-preview": {
      const settings = await readSettings();
      const next = { ...settings, previewSample: message.enabled };
      await writeSettings(next);
      return { ok: true, data: next };
    }
    case "set-pinned": {
      const settings = await readSettings();
      const next = { ...settings, sidebarPinned: message.enabled };
      await writeSettings(next);
      return { ok: true, data: next };
    }
    case "get-collection":
      return { ok: true, data: await getCollection(message.force === true) };
    case "search":
      return { ok: true, data: await search(message.term) };
    case "translate":
      return { ok: true, data: await translate(message.text) };
    case "add-card":
      return { ok: true, data: await addCard(message) };
    case "test-connection":
      return { ok: true, data: await testConnection() };
    case "auth-callback":
      await finishLogin(message.code, message.state, message.error);
      return { ok: true, data: null };
    case "owns-login-state": {
      const pending = await readPendingLogin();
      const claimed = await readClaimedLoginStates();
      return {
        ok: true,
        data: {
          matches: extensionOwnsLoginState(
            pending?.state ?? null,
            [...claimedLoginStates, ...claimed],
            message.state
          )
        }
      };
    }
    case "auth0-cache": {
      const senderUrl = sender.url ?? sender.tab?.url ?? "";
      if (!senderUrl.startsWith(`${AUTH0_REDIRECT_URI}/`) && senderUrl !== AUTH0_REDIRECT_URI) {
        return { ok: false, error: "Ignored sign-in data from this page." };
      }
      const settings = await readSettings();
      if (settings.manualToken.trim().length > 0) {
        return { ok: true, data: null };
      }
      const existing = await readSession();
      const next = sessionAfterHarvest(existing, {
        accessToken: message.accessToken,
        expiresAt: message.expiresAt
      });
      if (!next) {
        return { ok: true, data: null };
      }
      await writeSession(next);
      await clearCollection();
      await broadcast({ type: "session-changed" });
      return { ok: true, data: null };
    }
    default:
      return { ok: false, error: "Unknown request." };
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  void handle(message, sender).then((response) => sendResponse(response)).catch((error) => {
    const text = error instanceof Error ? error.message : "Something went wrong.";
    const response = { ok: false, error: text };
    sendResponse(response);
  });
  return true;
});
chrome.tabs.onUpdated.addListener((tabId, _info, tab) => {
  if (typeof tab.url === "string") {
    void captureLoginRedirect(tabId, tab.url).catch(() => {
    });
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  void readPendingLogin().then((pending) => {
    if (pending?.tabId === tabId && !claimedLoginStates.has(pending.state)) {
      void writePendingLogin(null);
    }
  });
});
chrome.commands.onCommand.addListener((command) => {
  if (command !== "toggle-reading") {
    return;
  }
  void readSettings().then(async (settings) => {
    const enabled = !settings.readingEnabled;
    await writeSettings({ ...settings, readingEnabled: enabled });
    await broadcast({ type: "reading-changed", enabled });
  });
});
