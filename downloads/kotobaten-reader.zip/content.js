"use strict";
(() => {
  // ../../packages/dictionary/src/verb-normalization.ts
  var conjugationPatterns = [
    "\u3059\u308B",
    "\u3063\u305F",
    "\u3044\u305F",
    "\u3057\u305F",
    "\u3093\u3060",
    "\u308C\u305F",
    "\u3048\u305F",
    "\u305F",
    "\u3063\u3066",
    "\u3044\u3066",
    "\u3057\u3066",
    "\u3093\u3067",
    "\u308C\u3066",
    "\u3079\u3066",
    "\u3048\u308B",
    "\u3051\u308B",
    "\u305B\u308B",
    "\u306D\u308B",
    "\u3079\u308B",
    "\u3081\u308B",
    "\u3066\u308B",
    "\u308C\u308B",
    "\u308F\u308C\u308B",
    "\u304B\u308C\u308B",
    "\u3055\u308C\u308B",
    "\u306A\u308C\u308B",
    "\u3070\u308C\u308B",
    "\u307E\u308C\u308B",
    "\u305F\u308C\u308B",
    "\u3089\u308C\u308B",
    "\u308F\u305B\u308B",
    "\u304B\u305B\u308B",
    "\u3055\u305B\u308B",
    "\u306A\u305B\u308B",
    "\u3070\u305B\u308B",
    "\u307E\u305B\u308B",
    "\u305F\u305B\u308B",
    "\u3089\u305B\u308B",
    "\u308F\u306A\u3044",
    "\u304B\u306A\u3044",
    "\u3055\u306A\u3044",
    "\u306A\u306A\u3044",
    "\u3070\u306A\u3044",
    "\u307E\u306A\u3044",
    "\u305F\u306A\u3044",
    "\u3089\u306A\u3044",
    "\u306A\u3044"
  ].sort((left, right) => right.length - left.length);
  function getVerbStem(term) {
    if (term.length === 0) {
      return term;
    }
    for (const suffix of conjugationPatterns) {
      if (term.endsWith(suffix)) {
        return term.slice(0, term.length - suffix.length);
      }
    }
    return term;
  }

  // src/lib/collection-match.ts
  var SENTENCE_BOUNDARIES = "\u3002\uFF0E\uFF01\uFF1F!?.\n";
  function compositeRetention(senseRetention, kanaRetention) {
    if (senseRetention == null && kanaRetention == null) {
      return null;
    }
    if (senseRetention == null) {
      return kanaRetention;
    }
    if (kanaRetention == null) {
      return senseRetention;
    }
    return Math.min(senseRetention, kanaRetention);
  }
  function displaySurface(card2) {
    const kanji = card2.kanji?.trim() ?? "";
    if (kanji.length > 0) {
      return kanji;
    }
    const kana = card2.kana?.trim() ?? "";
    if (kana.length > 0) {
      return kana;
    }
    return card2.sense.trim();
  }
  function addExactSurface(lexicon, surface, card2) {
    const trimmed = surface.trim();
    if (trimmed.length === 0 || lexicon.exactBySurface.has(trimmed)) {
      return;
    }
    lexicon.exactBySurface.set(trimmed, card2);
    const first = trimmed[0];
    const bucket = lexicon.byFirst.get(first);
    if (bucket) {
      bucket.push(trimmed);
    } else {
      lexicon.byFirst.set(first, [trimmed]);
    }
  }
  function dictionaryFormStems(form) {
    const trimmed = form.trim();
    if (trimmed.length < 2) {
      return [];
    }
    const stems = /* @__PURE__ */ new Set();
    if (trimmed.endsWith("\u3059\u308B") && trimmed.length > 2) {
      stems.add(trimmed.slice(0, -2));
    }
    if (trimmed.endsWith("\u304F\u308B") && trimmed.length > 2) {
      stems.add(trimmed.slice(0, -2));
    }
    const godanEndings = ["\u308B", "\u3046", "\u304F", "\u3050", "\u3059", "\u3064", "\u306C", "\u3076", "\u3080"];
    for (const ending of godanEndings) {
      if (trimmed.endsWith(ending) && trimmed.length > ending.length) {
        stems.add(trimmed.slice(0, -ending.length));
      }
    }
    return [...stems].filter((stem) => stem.length > 0);
  }
  function addStem(lexicon, form, card2) {
    for (const stem of dictionaryFormStems(form)) {
      if (!lexicon.stemByStem.has(stem)) {
        lexicon.stemByStem.set(stem, card2);
        lexicon.stemFirst.add(stem[0]);
      }
    }
  }
  function buildLexicon(cards) {
    const lexicon = {
      byFirst: /* @__PURE__ */ new Map(),
      exactBySurface: /* @__PURE__ */ new Map(),
      stemByStem: /* @__PURE__ */ new Map(),
      stemFirst: /* @__PURE__ */ new Set()
    };
    for (const card2 of cards) {
      if (card2.type === "Grammar") {
        addExactSurface(lexicon, card2.sense, card2);
        continue;
      }
      const kanji = card2.kanji?.trim() ?? "";
      const kana = card2.kana?.trim() ?? "";
      if (kanji.length > 0) {
        addExactSurface(lexicon, kanji, card2);
        addStem(lexicon, kanji, card2);
      }
      if (kana.length > 0) {
        addExactSurface(lexicon, kana, card2);
        addStem(lexicon, kana, card2);
      }
    }
    for (const surfaces of lexicon.byFirst.values()) {
      surfaces.sort((a, b) => b.length - a.length);
    }
    return lexicon;
  }
  function tryExactMatch(plainText, index, lexicon) {
    const surfaces = lexicon.byFirst.get(plainText[index]);
    if (!surfaces) {
      return null;
    }
    for (const surface of surfaces) {
      if (!plainText.startsWith(surface, index)) {
        continue;
      }
      const card2 = lexicon.exactBySurface.get(surface);
      if (!card2) {
        continue;
      }
      return {
        card: card2,
        matchedText: surface,
        start: index,
        end: index + surface.length
      };
    }
    return null;
  }
  function tryVerbStemMatch(plainText, index, lexicon) {
    if (!lexicon.stemFirst.has(plainText[index])) {
      return null;
    }
    const maxLen = Math.min(20, plainText.length - index);
    for (let len = maxLen; len >= 2; len--) {
      const candidate = plainText.slice(index, index + len);
      const stem = getVerbStem(candidate);
      if (stem === candidate || stem.length === 0) {
        continue;
      }
      const card2 = lexicon.stemByStem.get(stem);
      if (!card2) {
        continue;
      }
      return {
        card: card2,
        matchedText: candidate,
        start: index,
        end: index + len
      };
    }
    return null;
  }
  function extractSentence(plainText, start2, end) {
    let sentenceStart = 0;
    let sentenceEnd = plainText.length;
    for (let i = start2 - 1; i >= 0; i--) {
      if (SENTENCE_BOUNDARIES.includes(plainText[i])) {
        sentenceStart = i + 1;
        break;
      }
    }
    for (let i = end; i < plainText.length; i++) {
      if (SENTENCE_BOUNDARIES.includes(plainText[i])) {
        sentenceEnd = i + 1;
        break;
      }
    }
    return plainText.slice(sentenceStart, sentenceEnd).replace(/\s+/g, " ").trim();
  }
  function matchWithLexicon(plainText, lexicon) {
    if (plainText.length === 0) {
      return [];
    }
    const hits = [];
    let i = 0;
    while (i < plainText.length) {
      const exact = tryExactMatch(plainText, i, lexicon);
      if (exact) {
        hits.push(exact);
        i = exact.end;
        continue;
      }
      const verb = tryVerbStemMatch(plainText, i, lexicon);
      if (verb) {
        hits.push(verb);
        i = verb.end;
        continue;
      }
      i += 1;
    }
    const byCardId = /* @__PURE__ */ new Map();
    for (const hit of hits) {
      let entry = byCardId.get(hit.card.id);
      if (!entry) {
        entry = { card: hit.card, occurrences: [] };
        byCardId.set(hit.card.id, entry);
      }
      entry.occurrences.push({
        matchedText: hit.matchedText,
        start: hit.start,
        end: hit.end,
        sentence: extractSentence(plainText, hit.start, hit.end)
      });
    }
    const matches = [];
    for (const { card: card2, occurrences } of byCardId.values()) {
      matches.push({
        cardId: card2.id,
        surface: displaySurface(card2),
        cardType: card2.type,
        retention: compositeRetention(card2.senseRetention, card2.kanaRetention),
        senseRetention: card2.senseRetention,
        kanaRetention: card2.kanaRetention,
        frequency: occurrences.length,
        occurrences,
        card: card2
      });
    }
    matches.sort((a, b) => {
      if (a.retention == null && b.retention != null) {
        return -1;
      }
      if (a.retention != null && b.retention == null) {
        return 1;
      }
      if (a.retention != null && b.retention != null && a.retention !== b.retention) {
        return a.retention - b.retention;
      }
      return b.frequency - a.frequency;
    });
    return matches;
  }
  function createMatcher(cards) {
    const lexicon = buildLexicon(cards);
    return (plainText) => matchWithLexicon(plainText, lexicon);
  }
  function sortMatches(matches, sort) {
    const list = [...matches];
    if (sort === "frequency") {
      list.sort((a, b) => {
        const byFreq = b.frequency - a.frequency;
        if (byFreq !== 0) {
          return byFreq;
        }
        const aRet = a.retention ?? -1;
        const bRet = b.retention ?? -1;
        return aRet - bRet;
      });
      return list;
    }
    list.sort((a, b) => {
      if (a.retention == null && b.retention != null) {
        return -1;
      }
      if (a.retention != null && b.retention == null) {
        return 1;
      }
      if (a.retention != null && b.retention != null && a.retention !== b.retention) {
        return a.retention - b.retention;
      }
      return b.frequency - a.frequency;
    });
    return list;
  }

  // src/lib/cards.ts
  function isHeadwordInCollection(entry, cards) {
    const kanji = entry.kanji.trim();
    const kana = entry.kana.trim();
    const forms = (value) => {
      const accepted = /* @__PURE__ */ new Set();
      if (value.length === 0) {
        return accepted;
      }
      accepted.add(value);
      if (entry.suru && !value.endsWith(SURU_SUFFIX)) {
        accepted.add(`${value}${SURU_SUFFIX}`);
      }
      return accepted;
    };
    const kanjiForms = forms(kanji);
    const kanaForms = forms(kana);
    return cards.some((card2) => {
      const cardKanji = card2.kanji?.trim() ?? "";
      const cardKana = card2.kana?.trim() ?? "";
      if (kanji.length > 0) {
        return kanjiForms.has(cardKanji);
      }
      return kana.length > 0 && cardKanji.length === 0 && kanaForms.has(cardKana);
    });
  }
  var SURU_SUFFIX = "\u3059\u308B";
  function cardPrefill(entry, sentence) {
    const withSuru = (value) => !entry.suru || value.length === 0 || value.endsWith(SURU_SUFFIX) ? value : `${value}${SURU_SUFFIX}`;
    const kanji = withSuru(entry.kanji);
    const kana = withSuru(entry.kana);
    const sample = sentence.trim();
    const bare = new Set(
      [entry.kanji, entry.kana, kanji, kana].filter((value) => value.length > 0)
    );
    return {
      kanji,
      kana,
      sense: entry.sense,
      note: sample.length > 0 && !bare.has(sample) ? sample : ""
    };
  }

  // src/lib/japanese.ts
  var JAPANESE_SOURCE = "[\\u3040-\\u30ff\\uff66-\\uff9d\\u31f0-\\u31ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff]";
  var LATIN_SOURCE = "[A-Za-z]";
  function countMatches(text, source) {
    return text.match(new RegExp(source, "gu"))?.length ?? 0;
  }
  function detectJapanese(text, htmlLang = "") {
    const japaneseChars = countMatches(text, JAPANESE_SOURCE);
    const latinChars = countMatches(text, LATIN_SOURCE);
    const denominator = japaneseChars + latinChars;
    const ratio = denominator === 0 ? 0 : japaneseChars / denominator;
    const langJa = htmlLang.trim().toLowerCase().startsWith("ja");
    const japanese = japaneseChars >= 80 || japaneseChars >= 40 && ratio >= 0.18 || langJa && japaneseChars >= 8;
    return { japanese, japaneseChars, ratio };
  }
  function containsJapanese(text) {
    return new RegExp(JAPANESE_SOURCE, "u").test(text);
  }

  // src/lib/retention.ts
  var RETENTION_BUCKETS = [
    "new",
    "poor",
    "mid",
    "strong"
  ];
  function retentionBucket(retention) {
    if (retention == null || Number.isNaN(retention)) {
      return "new";
    }
    if (retention < 0.4) {
      return "poor";
    }
    if (retention < 0.75) {
      return "mid";
    }
    return "strong";
  }
  function highlightName(bucket) {
    return `kotobaten-${bucket}`;
  }
  function retentionLabel(retention) {
    if (retention == null || Number.isNaN(retention)) {
      return "Not studied yet";
    }
    const percent = Math.round(Math.min(1, Math.max(0, retention)) * 100);
    return `${percent}% retention`;
  }

  // src/lib/sample-cards.ts
  var SAMPLE_CARDS = [
    card("keizai", "economy", "\u7D4C\u6E08", "\u3051\u3044\u3056\u3044", 0.22, 0.5),
    card("kigyo", "enterprise; company", "\u4F01\u696D", "\u304D\u304E\u3087\u3046", null, null),
    card("shijo", "market", "\u5E02\u5834", "\u3057\u3058\u3087\u3046", 0.86, 0.9),
    card("seifu", "government", "\u653F\u5E9C", "\u305B\u3044\u3075", 0.45, 0.6),
    card("seicho", "growth", "\u6210\u9577", "\u305B\u3044\u3061\u3087\u3046", 0.15, 0.4),
    card("nihon", "Japan", "\u65E5\u672C", "\u306B\u307B\u3093", 0.95, 0.95),
    card("sekai", "world", "\u4E16\u754C", "\u305B\u304B\u3044", 0.7, 0.8),
    card("kabuka", "stock price", "\u682A\u4FA1", "\u304B\u3076\u304B", null, null),
    card("en", "yen", "\u5186", "\u3048\u3093", 0.6, 0.6),
    card("ginko", "bank", "\u9280\u884C", "\u304E\u3093\u3053\u3046", 0.33, 0.5),
    card("toshi", "investment", "\u6295\u8CC7", "\u3068\u3046\u3057", 0.1, 0.2),
    card("bukka", "prices", "\u7269\u4FA1", "\u3076\u3063\u304B", null, null),
    card("kinri", "interest rate", "\u91D1\u5229", "\u304D\u3093\u308A", 0.05, 0.2),
    card("tokyo", "Tokyo", "\u6771\u4EAC", "\u3068\u3046\u304D\u3087\u3046", 0.92, 0.92),
    card("kotoshi", "this year", "\u4ECA\u5E74", "\u3053\u3068\u3057", 0.55, 0.4),
    card("happy", "to announce", "\u767A\u8868", "\u306F\u3063\u3074\u3087\u3046", 0.28, 0.35),
    card("kaisha", "company", "\u4F1A\u793E", "\u304B\u3044\u3057\u3083", 0.8, 0.85),
    card("nikkei", "Nikkei", "\u65E5\u7D4C", "\u306B\u3063\u3051\u3044", null, null)
  ];
  function card(id, sense, kanji, kana, senseRetention, kanaRetention) {
    return {
      id: `sample-${id}`,
      type: "Word",
      sense,
      kanji,
      kana,
      senseRetention,
      kanaRetention
    };
  }

  // src/content/content.ts
  var HOST_ID = "kotobaten-root";
  var HIGHLIGHT_STYLE_ID = "kotobaten-highlight-style";
  var SKIP_TAGS = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "TEXTAREA",
    "INPUT",
    "SELECT",
    "OPTION",
    "CODE"
  ]);
  var MAX_TEXT_NODES = 1800;
  var MAX_SCAN_CHARS = 14e4;
  var TRANSLATE_LIMIT = 900;
  var state = {
    readingEnabled: false,
    signedIn: false,
    japanese: false,
    japaneseChars: 0,
    loading: false,
    error: null,
    preview: false,
    cards: [],
    hits: [],
    words: [],
    sort: "retention",
    sortMenuOpen: false,
    drawerOpen: false,
    sidebarPinned: false,
    panel: "words"
  };
  var host = null;
  var shadow = null;
  var scanTimer = 0;
  var lookupSeq = 0;
  var readingGeneration = 0;
  var drawerDismissed = false;
  function request(message) {
    return chrome.runtime.sendMessage(message);
  }
  function pageState() {
    return {
      japanese: state.japanese,
      japaneseChars: state.japaneseChars,
      readingEnabled: state.readingEnabled,
      signedIn: state.signedIn,
      loading: state.loading,
      error: state.error,
      matchCount: state.words.length,
      preview: state.preview,
      host: location.hostname
    };
  }
  function ignoredHost() {
    return location.hostname === "web.kotobaten.app" || location.hostname.endsWith(".auth0.com");
  }
  function harvestWebSession() {
    if (location.hostname !== "web.kotobaten.app") {
      return;
    }
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (!key || !key.startsWith("@@auth0spajs@@")) {
        continue;
      }
      try {
        const parsed = JSON.parse(localStorage.getItem(key) ?? "");
        const body = parsed.body;
        const accessToken = body?.access_token;
        if (typeof accessToken !== "string" || accessToken.length === 0) {
          continue;
        }
        if (body?.audience && body.audience !== "https://kotobaten.app/api") {
          continue;
        }
        const expiresAt = typeof parsed.expiresAt === "number" ? parsed.expiresAt * 1e3 : Date.now() + 60 * 60 * 1e3;
        void request({ type: "auth0-cache", accessToken, expiresAt });
      } catch {
      }
    }
  }
  var HIGHLIGHT_CSS = `
::highlight(kotobaten-new) {
  text-decoration-line: underline;
  text-decoration-color: #c41e3a;
  text-decoration-thickness: 2px;
  text-underline-offset: 0.18em;
}
::highlight(kotobaten-poor) {
  text-decoration-line: underline;
  text-decoration-color: #d4566a;
  text-decoration-thickness: 2px;
  text-underline-offset: 0.18em;
}
::highlight(kotobaten-mid) {
  text-decoration-line: underline;
  text-decoration-color: #8a93a0;
  text-decoration-thickness: 1px;
  text-underline-offset: 0.2em;
}
::highlight(kotobaten-strong) {
  text-decoration-line: underline;
  text-decoration-color: rgba(138, 147, 160, 0.55);
  text-decoration-thickness: 1px;
  text-underline-offset: 0.2em;
}
::highlight(kotobaten-focus) {
  background-color: #fff1b8;
  text-decoration-line: underline;
  text-decoration-color: #c41e3a;
  text-decoration-thickness: 2px;
}
`;
  var UI_CSS = `
:host {
  all: initial;
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  pointer-events: none;
  color: #2c3e50;
  font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", "Hiragino Sans", "Noto Sans JP", sans-serif;
  font-size: 14px;
  line-height: 1.45;
}
button, input { font: inherit; color: inherit; }
.edge, .drawer, .tooltip { pointer-events: auto; }
.edge {
  position: fixed;
  top: 40%;
  right: 0;
  border: 1px solid #e1e8ed;
  border-right: 0;
  background: #fff;
  border-radius: 8px 0 0 8px;
  padding: 8px;
  cursor: pointer;
}
.edge img { width: 32px; height: 32px; display: block; }
.drawer {
  position: fixed;
  top: 0;
  right: 0;
  height: 100vh;
  width: min(380px, 100vw);
  background: #fff;
  border-left: 1px solid #e1e8ed;
  display: flex;
  flex-direction: column;
}
.drawer header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 16px 16px 8px;
}
.wordmark { height: 32px; width: auto; display: block; }
.header-actions { display: flex; align-items: center; gap: 8px; }
.icon-btn {
  width: 32px;
  height: 32px;
  border: 0;
  background: transparent;
  border-radius: 8px;
  padding: 0;
  cursor: pointer;
  color: #5a6c7d;
  display: grid;
  place-items: center;
}
.icon-btn[aria-pressed="true"] { color: #c41e3a; background: rgba(196, 30, 58, 0.08); }
.icon-btn[aria-expanded="true"] { background: #f8f9fa; color: #2c3e50; }
.icon-btn svg { width: 18px; height: 18px; display: block; }
.reading-row {
  margin: 0 16px;
  padding: 12px 0;
  border-bottom: 1px solid #e1e8ed;
}
.switch {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  cursor: pointer;
}
.switch input { position: absolute; opacity: 0; width: 1px; height: 1px; }
.track { width: 36px; height: 22px; border-radius: 999px; background: #d5dde3; position: relative; flex: none; }
.track::after {
  content: "";
  position: absolute;
  top: 2px; left: 2px;
  width: 18px; height: 18px;
  border-radius: 50%;
  background: white;
  transition: transform 0.15s ease;
}
.switch input:checked + .track { background: #c41e3a; }
.switch input:checked + .track::after { transform: translateX(14px); }
.switch input:focus-visible + .track { outline: 2px solid #2c3e50; outline-offset: 2px; }
.status-row {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 12px 16px 16px;
}
.status {
  margin: 0;
  padding-top: 6px;
  flex: 1;
  color: #5a6c7d;
  font-size: 14px;
}
.sort { position: relative; flex: none; }
.sort-menu {
  position: absolute;
  top: calc(100% + 4px);
  right: 0;
  z-index: 2;
  min-width: 168px;
  padding: 4px;
  background: #fff;
  border: 1px solid #e1e8ed;
  border-radius: 8px;
  box-shadow: 0 8px 24px rgba(44, 62, 80, 0.12);
}
.sort-menu button {
  display: block;
  width: 100%;
  margin: 0;
  padding: 8px 12px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: #2c3e50;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.sort-menu button[aria-checked="true"] { background: #f8f9fa; font-weight: 600; }
.sort-menu button:hover { background: #f8f9fa; }
.views {
  flex: 1;
  min-height: 0;
  display: grid;
  overflow: hidden;
}
.pane {
  position: relative;
  grid-area: 1 / 1;
  min-height: 0;
  height: 100%;
  overflow: auto;
  padding: 12px 16px 32px;
  opacity: 1;
  transform: none;
  transition: opacity 180ms ease, transform 180ms ease;
  z-index: 1;
}
.views > .pane.hidden {
  display: block !important;
  opacity: 0;
  transform: translateY(8px);
  visibility: hidden;
  pointer-events: none;
  z-index: 0;
}
.pane.pane-in { animation: pane-in 180ms ease; }
@keyframes pane-in {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: none; }
}
@media (prefers-reduced-motion: reduce) {
  .pane { transition: none; }
  .pane.pane-in { animation: none; }
}
.term { font-size: 20px; font-weight: 600; margin: 2px 0 0; line-height: 1.2; }
.kana { color: #5a6c7d; font-size: 12px; margin-top: 2px; }
.sense, .gloss { margin: 8px 0 0; font-size: 14px; color: #5a6c7d; }
.meta { margin-top: 2px; font-size: 12px; color: #5a6c7d; }
.section { margin-top: 16px; padding-top: 16px; border-top: 1px solid #e1e8ed; }
.section h3 { margin: 0 0 12px; font-size: 14px; font-weight: 700; color: #5a6c7d; }
.entry {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 0;
}
.entry-text { flex: 1; min-width: 0; }
.add-btn {
  width: 28px;
  height: 28px;
  flex: none;
  color: #5a6c7d;
}
.add-btn svg { width: 16px; height: 16px; display: block; }
.add-btn.collected {
  display: grid;
  place-items: center;
}
.add-form {
  margin: 0 0 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #e1e8ed;
}
.add-form h3 { margin: 0 0 12px; font-size: 14px; font-weight: 700; color: #5a6c7d; }
.add-form label { display: block; margin-top: 12px; font-size: 12px; color: #5a6c7d; }
.add-form input, .add-form textarea {
  display: block;
  width: 100%;
  box-sizing: border-box;
  margin-top: 4px;
  padding: 8px 12px;
  border: 1px solid #e1e8ed;
  border-radius: 8px;
  background: #fff;
  color: #2c3e50;
  font: inherit;
}
.add-form textarea { min-height: 72px; resize: vertical; }
.form-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px; }
.form-error { margin: 12px 0 0; color: #c41e3a; font-size: 14px; }
.word-surface { font-size: 18px; font-weight: 600; }
.btn, .text-btn {
  border: 1px solid #e1e8ed;
  background: #fff;
  border-radius: 8px;
  padding: 8px 12px;
  cursor: pointer;
}
.btn.primary { background: #c41e3a; color: #fff; border-color: #c41e3a; }
.btn.quiet {
  background: transparent;
  color: #5a6c7d;
  border-color: #e1e8ed;
  font-weight: 600;
}
.btn.quiet:hover { background: #f8f9fa; color: #2c3e50; }
.btn:disabled { opacity: 0.6; cursor: default; }
.translation-result { margin: 12px 0 0; color: #2c3e50; font-size: 14px; }
.text-btn { border: 0; background: transparent; color: #c41e3a; padding: 0; font-weight: 600; margin-bottom: 12px; }
.words { list-style: none; margin: 8px -16px 0; padding: 0; }
.words li + li { border-top: 1px solid #e1e8ed; }
.words button {
  width: 100%;
  text-align: left;
  border: 0;
  background: transparent;
  border-radius: 0;
  padding: 12px 16px;
  cursor: pointer;
}
.words button:hover { background: #f8f9fa; }
.row-top { display: flex; align-items: center; gap: 8px; }
.row-top .word-surface { flex: 1; }
.dot { width: 8px; height: 8px; border-radius: 50%; background: #c5cdd4; flex: none; }
.dot.new { background: #ffc107; }
.freq { color: #5a6c7d; font-size: 12px; font-weight: 600; }
.auth-actions { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; }
.tooltip {
  position: fixed;
  background: #fff;
  border: 1px solid #e1e8ed;
  border-radius: 8px;
  padding: 8px;
  box-shadow: 0 8px 24px rgba(44, 62, 80, 0.12);
  max-width: 240px;
}
.hidden { display: none !important; }
.muted { color: #5a6c7d; margin: 0; }
`;
  function ensureHighlightStyle() {
    if (document.getElementById(HIGHLIGHT_STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = HIGHLIGHT_STYLE_ID;
    style.textContent = HIGHLIGHT_CSS;
    document.documentElement.appendChild(style);
  }
  function highlightRegistry() {
    if (typeof Highlight === "undefined" || typeof CSS === "undefined" || !("highlights" in CSS)) {
      return null;
    }
    return CSS.highlights;
  }
  function clearHighlights() {
    const registry = highlightRegistry();
    if (!registry) {
      return;
    }
    for (const bucket of RETENTION_BUCKETS) {
      registry.delete(highlightName(bucket));
    }
    registry.delete("kotobaten-focus");
  }
  function highlightsSupported() {
    return highlightRegistry() != null;
  }
  function mount() {
    if (document.getElementById(HOST_ID)) {
      return;
    }
    host = document.createElement("div");
    host.id = HOST_ID;
    host.setAttribute("data-kotobaten-root", "");
    shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = UI_CSS;
    shadow.append(style, renderShell());
    document.documentElement.appendChild(host);
    ensureHighlightStyle();
    bindShell();
    render();
  }
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text != null) {
      node.textContent = text;
    }
    return node;
  }
  function assetUrl(file) {
    return chrome.runtime.getURL(`assets/${file}`);
  }
  function renderShell() {
    const root = el("div");
    const edge = el("button", "edge");
    edge.type = "button";
    edge.dataset.action = "open-drawer";
    edge.title = "Open Kotobaten";
    const mark = document.createElement("img");
    mark.src = assetUrl("logo_square_color.png");
    mark.alt = "Kotobaten";
    edge.append(mark);
    const drawer = el("aside", "drawer hidden");
    drawer.dataset.region = "drawer";
    const header = el("header");
    const wordmark = document.createElement("img");
    wordmark.className = "wordmark";
    wordmark.src = assetUrl("logo_wide_color.png");
    wordmark.alt = "kotobaten";
    const actions = el("div", "header-actions");
    const pin = el("button", "icon-btn");
    pin.type = "button";
    pin.dataset.action = "pin";
    pin.title = "Pin sidebar";
    pin.setAttribute("aria-label", "Pin sidebar");
    pin.innerHTML = pinIcon(false);
    const close = el("button", "icon-btn");
    close.type = "button";
    close.dataset.action = "close-drawer";
    close.title = "Close";
    close.setAttribute("aria-label", "Close sidebar");
    close.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" fill="none"/></svg>';
    actions.append(pin, close);
    header.append(wordmark, actions);
    const reading = el("div", "reading-row");
    const label = document.createElement("label");
    label.className = "switch";
    const caption = el("span", void 0, "Underline my words");
    const input = el("input");
    input.type = "checkbox";
    input.dataset.action = "toggle";
    input.setAttribute("aria-label", "Underline words from your collection");
    const track = el("span", "track");
    label.append(caption, input, track);
    reading.append(label);
    const statusRow = el("div", "status-row");
    statusRow.dataset.region = "status-row";
    const status = el("p", "status");
    status.dataset.region = "status";
    statusRow.append(status, sortControl());
    const views = el("div", "views");
    const lookup = el("div", "pane hidden");
    lookup.dataset.region = "lookup";
    const words = el("div", "pane");
    words.dataset.region = "words";
    views.append(lookup, words);
    drawer.append(header, reading, statusRow, views);
    const tooltip = el("div", "tooltip hidden");
    tooltip.dataset.region = "tooltip";
    root.append(edge, drawer, tooltip);
    return root;
  }
  function region(name) {
    return shadow?.querySelector(`[data-region="${name}"]`) ?? null;
  }
  function bindShell() {
    shadow?.addEventListener("pointerdown", () => {
      window.getSelection()?.removeAllRanges();
    });
    shadow?.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      const action = target.closest("[data-action]")?.dataset.action;
      const closedMenu = state.sortMenuOpen && action !== "sort-menu" && action !== "sort";
      if (closedMenu) {
        state.sortMenuOpen = false;
      }
      if (action === "open-drawer") {
        drawerDismissed = false;
        state.drawerOpen = true;
        state.panel = "words";
        render();
      } else if (action === "close-drawer") {
        state.drawerOpen = false;
        drawerDismissed = true;
        render();
      } else if (action === "pin") {
        state.sidebarPinned = !state.sidebarPinned;
        drawerDismissed = false;
        state.drawerOpen = true;
        void request({ type: "set-pinned", enabled: state.sidebarPinned });
        render();
      } else if (action === "show-words") {
        state.panel = "words";
        state.drawerOpen = true;
        render();
      } else if (action === "sign-in") {
        void request({ type: "sign-in" });
      } else if (action === "preview") {
        state.preview = !state.preview;
        void request({ type: "set-preview", enabled: state.preview });
        void applyReading();
      } else if (action === "sort-menu") {
        state.sortMenuOpen = !state.sortMenuOpen;
        render();
      } else if (action === "sort") {
        const next = target.closest("[data-sort]")?.dataset.sort;
        state.sortMenuOpen = false;
        if (next === "retention" || next === "frequency") {
          state.sort = next;
        }
        render();
      } else if (action === "focus-word") {
        const id = target.closest("[data-card-id]")?.dataset.cardId;
        const word = state.words.find((item) => item.match.cardId === id);
        if (word) {
          focusHit(word.hit);
        }
      } else if (action === "translate") {
        const term = region("lookup")?.dataset.term ?? "";
        void runTranslation(term, lookupSeq);
      } else if (action === "add-card") {
        const button2 = target.closest("[data-kanji]");
        if (button2) {
          openAddForm(button2);
        }
      } else if (action === "cancel-add") {
        region("add-form")?.remove();
      } else if (action === "close-lookup") {
        state.panel = "words";
        render();
      }
      if (closedMenu) {
        render();
      }
    });
    shadow?.addEventListener("change", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLInputElement) || target.dataset.action !== "toggle") {
        return;
      }
      void request({ type: "set-reading", enabled: target.checked });
      state.readingEnabled = target.checked;
      state.drawerOpen = true;
      void applyReading();
    });
  }
  function statusText() {
    if (!state.readingEnabled) {
      return "Turn on underlines to mark words from your collection. Select text to look it up.";
    }
    if (state.loading) {
      return "Loading your collection\u2026";
    }
    if (state.error && !state.preview) {
      return state.error;
    }
    if (state.preview) {
      return `Sample preview \xB7 ${state.words.length} news words. Sign in for your collection.`;
    }
    if (state.words.length === 0) {
      return "None of your words appear in the text on this page.";
    }
    const noun = state.words.length === 1 ? "word" : "words";
    return `${state.words.length} ${noun} from your collection on this page.`;
  }
  function render() {
    if (!host || !shadow) {
      return;
    }
    host.style.display = state.japanese ? "" : "none";
    const edge = shadow.querySelector(".edge");
    edge?.classList.toggle("hidden", state.drawerOpen);
    const toggle = shadow.querySelector(
      '[data-action="toggle"]'
    );
    if (toggle) {
      toggle.checked = state.readingEnabled;
    }
    const pin = shadow.querySelector('[data-action="pin"]');
    if (pin) {
      pin.setAttribute("aria-pressed", state.sidebarPinned ? "true" : "false");
      pin.innerHTML = pinIcon(state.sidebarPinned);
      pin.title = state.sidebarPinned ? "Unpin sidebar" : "Pin sidebar";
      pin.setAttribute(
        "aria-label",
        state.sidebarPinned ? "Unpin sidebar" : "Pin sidebar"
      );
    }
    const drawer = region("drawer");
    drawer?.classList.toggle("hidden", !state.drawerOpen);
    const showLookup = state.panel === "lookup" && state.drawerOpen;
    const statusRow = region("status-row");
    statusRow?.classList.toggle("hidden", showLookup);
    const status = region("status");
    if (status && !showLookup) {
      status.textContent = statusText();
    }
    const sortMenu = shadow.querySelector(
      '[data-action="sort-menu"]'
    );
    sortMenu?.setAttribute(
      "aria-expanded",
      state.sortMenuOpen ? "true" : "false"
    );
    region("sort-menu")?.classList.toggle("hidden", !state.sortMenuOpen);
    shadow.querySelectorAll("[data-sort]").forEach((item) => {
      item.setAttribute(
        "aria-checked",
        item.dataset.sort === state.sort ? "true" : "false"
      );
    });
    const lookup = region("lookup");
    const words = region("words");
    lookup?.classList.toggle("hidden", !showLookup);
    words?.classList.toggle("hidden", showLookup);
    if (words && !showLookup && state.drawerOpen) {
      const scrollTop = words.scrollTop;
      fillDrawer(words);
      words.scrollTop = scrollTop;
    }
  }
  function button(text, action, primary) {
    const node = el("button", primary ? "btn primary" : "btn", text);
    node.type = "button";
    node.dataset.action = action;
    return node;
  }
  function fillDrawer(pane) {
    pane.replaceChildren();
    if (!state.signedIn) {
      const actions = el("div", "auth-actions");
      actions.append(button("Sign in", "sign-in", true));
      actions.append(
        button(
          state.preview ? "Hide sample" : "Preview sample",
          "preview",
          false
        )
      );
      pane.append(actions);
    }
    const ordered = sortMatches(
      state.words.map((item) => item.match),
      state.sort
    );
    if (ordered.length === 0) {
      pane.append(el("p", "muted", "No underlined words on this page."));
      return;
    }
    const list = el("ul", "words");
    for (const match of ordered) {
      const item = el("li");
      const row = el("button");
      row.type = "button";
      row.dataset.action = "focus-word";
      row.dataset.cardId = match.cardId;
      const top = el("div", "row-top");
      const dot = el(
        "span",
        `dot ${retentionBucket(match.retention) === "new" ? "new" : ""}`
      );
      top.append(dot, el("span", "word-surface", match.surface));
      top.append(el("span", "freq", `\xD7${match.frequency}`));
      const reading = match.card.kana && match.card.kana !== match.surface ? match.card.kana : "";
      row.append(top);
      if (reading) {
        row.append(el("div", "kana", reading));
      }
      row.append(el("div", "gloss", match.card.sense));
      row.append(el("div", "meta", retentionLabel(match.retention)));
      item.append(row);
      list.append(item);
    }
    pane.append(list);
  }
  function pinIcon(filled) {
    if (filled) {
      return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M16 9V4h1V2H7v2h1v5l-2.6 3.4A1 1 0 0 0 6.2 15H11v7h2v-7h4.8a1 1 0 0 0 .8-1.6L16 9z"/></svg>';
    }
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" d="M9 4h6M9.5 4v4.2L7 12.5h10l-2.5-4.3V4M12 12.5V21"/></svg>';
  }
  function sortControl() {
    const wrap = el("div", "sort");
    const button2 = el("button", "icon-btn");
    button2.type = "button";
    button2.dataset.action = "sort-menu";
    button2.title = "Sort";
    button2.setAttribute("aria-label", "Sort words");
    button2.setAttribute("aria-haspopup", "menu");
    button2.setAttribute("aria-expanded", "false");
    button2.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" d="M4 7h16M7 12h10M10 17h4"/></svg>';
    const menu = el("div", "sort-menu hidden");
    menu.dataset.region = "sort-menu";
    menu.setAttribute("role", "menu");
    menu.append(
      sortOption("Retention", "retention"),
      sortOption("Frequency", "frequency")
    );
    wrap.append(button2, menu);
    return wrap;
  }
  function sortOption(text, sort) {
    const node = el("button", void 0, text);
    node.type = "button";
    node.dataset.action = "sort";
    node.dataset.sort = sort;
    node.setAttribute("role", "menuitemradio");
    node.setAttribute("aria-checked", "false");
    return node;
  }
  function sampleText() {
    const chunks = [];
    let counted = 0;
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => acceptTextNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
      }
    );
    let current = walker.nextNode();
    while (current && counted < 12e3) {
      const value = current.nodeValue ?? "";
      chunks.push(value);
      counted += value.length;
      current = walker.nextNode();
    }
    return chunks.join("\n");
  }
  function acceptTextNode(node) {
    if (node.nodeType !== Node.TEXT_NODE) {
      return false;
    }
    const parent = node.parentElement;
    if (!parent || SKIP_TAGS.has(parent.tagName)) {
      return false;
    }
    if (parent.closest(`#${HOST_ID}, #${HIGHLIGHT_STYLE_ID}`)) {
      return false;
    }
    if (parent.isContentEditable) {
      return false;
    }
    const value = node.nodeValue ?? "";
    return value.trim().length > 0;
  }
  function detect() {
    if (!document.body || ignoredHost()) {
      state.japanese = false;
      state.japaneseChars = 0;
      render();
      return;
    }
    const detection = detectJapanese(
      sampleText(),
      document.documentElement.lang || ""
    );
    const changed = detection.japanese !== state.japanese;
    state.japanese = detection.japanese;
    state.japaneseChars = detection.japaneseChars;
    if (!state.japanese) {
      clearHighlights();
      state.hits = [];
      state.words = [];
      state.drawerOpen = false;
    } else if (state.sidebarPinned && !drawerDismissed) {
      state.drawerOpen = true;
    }
    if (state.japanese && changed && state.readingEnabled) {
      void applyReading();
    }
    render();
  }
  function readingRunIsCurrent(generation) {
    return generation === readingGeneration && state.readingEnabled;
  }
  async function applyReading() {
    const generation = ++readingGeneration;
    clearHighlights();
    state.hits = [];
    state.words = [];
    hideTooltip();
    if (!state.readingEnabled || !state.japanese) {
      state.loading = false;
      render();
      return;
    }
    if (!highlightsSupported()) {
      state.loading = false;
      state.error = "This browser cannot underline page text in place.";
      render();
      return;
    }
    state.loading = true;
    state.error = null;
    render();
    let cards = [];
    if (state.preview && !state.signedIn) {
      cards = [...SAMPLE_CARDS];
    } else {
      const response = await request({
        type: "get-collection"
      });
      if (!readingRunIsCurrent(generation)) {
        return;
      }
      if (!response.ok) {
        state.loading = false;
        state.error = response.error;
        render();
        return;
      }
      if (response.data.error) {
        state.error = response.data.error;
        if (state.preview) {
          cards = [...SAMPLE_CARDS];
        } else {
          state.loading = false;
          state.cards = [];
          render();
          return;
        }
      } else {
        cards = response.data.cards;
        if (state.preview) {
          state.preview = false;
          void request({ type: "set-preview", enabled: false });
        }
        state.error = null;
      }
    }
    if (!readingRunIsCurrent(generation)) {
      return;
    }
    state.cards = cards;
    state.loading = false;
    scan(cards);
    render();
  }
  function scan(cards) {
    clearHighlights();
    state.hits = [];
    state.words = [];
    if (!document.body || cards.length === 0 || !highlightsSupported()) {
      return;
    }
    const matchText = createMatcher(cards);
    const buckets = /* @__PURE__ */ new Map();
    for (const bucket of RETENTION_BUCKETS) {
      buckets.set(bucket, []);
    }
    const byCard = /* @__PURE__ */ new Map();
    let nodes = 0;
    let chars = 0;
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => acceptTextNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
      }
    );
    let current = walker.nextNode();
    while (current && nodes < MAX_TEXT_NODES && chars < MAX_SCAN_CHARS) {
      const textNode = current;
      const value = textNode.nodeValue ?? "";
      nodes += 1;
      chars += value.length;
      if (!containsJapanese(value)) {
        current = walker.nextNode();
        continue;
      }
      for (const match of matchText(value)) {
        for (const occurrence of match.occurrences) {
          const range = document.createRange();
          try {
            range.setStart(textNode, occurrence.start);
            range.setEnd(textNode, occurrence.end);
          } catch {
            continue;
          }
          const bucket = retentionBucket(match.retention);
          buckets.get(bucket)?.push(range);
          const hit = {
            node: textNode,
            start: occurrence.start,
            end: occurrence.end,
            matchedText: occurrence.matchedText,
            sentence: occurrence.sentence,
            card: match.card,
            retention: match.retention
          };
          state.hits.push(hit);
          const existing = byCard.get(match.cardId);
          if (existing) {
            existing.match = {
              ...existing.match,
              frequency: existing.match.frequency + 1,
              occurrences: existing.match.occurrences.concat(occurrence)
            };
          } else {
            byCard.set(match.cardId, {
              match: { ...match, occurrences: [occurrence], frequency: 1 },
              hit
            });
          }
        }
      }
      current = walker.nextNode();
    }
    for (const bucket of RETENTION_BUCKETS) {
      const ranges = buckets.get(bucket) ?? [];
      highlightRegistry()?.set(highlightName(bucket), new Highlight(...ranges));
    }
    state.words = [...byCard.values()];
  }
  function hitAt(x, y) {
    const range = document.caretRangeFromPoint(x, y);
    if (!range || range.startContainer.nodeType !== Node.TEXT_NODE) {
      return null;
    }
    const node = range.startContainer;
    const offset = range.startOffset;
    for (let index = state.hits.length - 1; index >= 0; index -= 1) {
      const hit = state.hits[index];
      if (hit.node === node && offset >= hit.start && offset < hit.end) {
        return hit;
      }
    }
    return null;
  }
  function showTooltip(hit, x, y) {
    const tooltip = region("tooltip");
    if (!tooltip) {
      return;
    }
    tooltip.classList.remove("hidden");
    tooltip.replaceChildren();
    tooltip.append(el("div", "word-surface", hit.matchedText));
    const reading = hit.card.kana && hit.card.kana !== hit.matchedText ? hit.card.kana : "";
    tooltip.append(
      el(
        "div",
        "muted",
        [
          reading,
          hit.card.sense,
          state.preview ? "Sample word" : "In your collection",
          retentionLabel(hit.retention)
        ].filter((part) => part.length > 0).join(" \xB7 ")
      )
    );
    place(tooltip, x, y);
  }
  function hideTooltip() {
    region("tooltip")?.classList.add("hidden");
  }
  function place(node, x, y) {
    const margin = 12;
    node.style.left = "0px";
    node.style.top = "0px";
    const rect = node.getBoundingClientRect();
    let left = x + 12;
    let top = y + 16;
    if (left + rect.width > window.innerWidth - margin) {
      left = Math.max(margin, window.innerWidth - rect.width - margin);
    }
    if (top + rect.height > window.innerHeight - margin) {
      top = Math.max(margin, y - rect.height - 12);
    }
    node.style.left = `${left}px`;
    node.style.top = `${top}px`;
  }
  function openLookup(term, sentence) {
    const lookup = region("lookup");
    if (!lookup) {
      return;
    }
    const seq = ++lookupSeq;
    const trimmed = term.trim();
    if (trimmed.length === 0 || !containsJapanese(trimmed)) {
      return;
    }
    const wasHidden = lookup.classList.contains("hidden");
    state.panel = "lookup";
    state.sortMenuOpen = false;
    drawerDismissed = false;
    state.drawerOpen = true;
    lookup.dataset.term = trimmed;
    lookup.dataset.sentence = sentence;
    lookup.replaceChildren();
    const back = el("button", "text-btn", "Words on this page");
    back.type = "button";
    back.dataset.action = "show-words";
    lookup.append(back);
    const local = localCollection(trimmed);
    if (local?.kana && local.kana !== trimmed) {
      lookup.append(el("div", "kana", local.kana));
    }
    lookup.append(el("p", "term", trimmed));
    if (sentence && sentence !== trimmed) {
      lookup.append(el("p", "muted", sentence));
    }
    if (local) {
      lookup.append(
        el(
          "p",
          "sense",
          `${state.preview ? "Sample word" : "In your collection"} \xB7 ${local.sense}`
        )
      );
      lookup.append(el("p", "meta", retentionLabel(composite(local))));
    }
    const translation = el("div", "section");
    translation.dataset.region = "translation";
    translation.append(el("h3", void 0, "Google Translate"));
    const translate = button("Translate", "translate", false);
    translate.classList.add("quiet");
    translation.append(translate);
    const dictionary = el("div", "section");
    dictionary.dataset.region = "dictionary";
    lookup.append(dictionary, translation);
    if (!wasHidden) {
      lookup.classList.remove("pane-in");
      void lookup.offsetWidth;
      lookup.classList.add("pane-in");
    }
    render();
    void runSearch(trimmed, seq);
  }
  function composite(card2) {
    if (card2.senseRetention == null) {
      return card2.kanaRetention;
    }
    if (card2.kanaRetention == null) {
      return card2.senseRetention;
    }
    return Math.min(card2.senseRetention, card2.kanaRetention);
  }
  function localCollection(term) {
    const trimmed = term.trim();
    return state.cards.find(
      (card2) => card2.kanji === trimmed || card2.kana === trimmed || card2.sense === trimmed
    ) ?? null;
  }
  function showTranslateButton(slot, message) {
    slot.replaceChildren(el("h3", void 0, "Google Translate"));
    const translate = button("Translate", "translate", false);
    translate.classList.add("quiet");
    slot.append(translate);
    if (message) {
      slot.append(el("p", "form-error", message));
    }
  }
  async function runTranslation(term, seq) {
    const slot = region("lookup")?.querySelector('[data-region="translation"]');
    if (!slot || term.length === 0) {
      return;
    }
    slot.replaceChildren(
      el("h3", void 0, "Google Translate"),
      el("p", "translation-result", "Translating\u2026")
    );
    const text = term.length > TRANSLATE_LIMIT ? term.slice(0, TRANSLATE_LIMIT) : term;
    let response;
    try {
      response = await request({ type: "translate", text });
    } catch (error) {
      response = {
        ok: false,
        error: error instanceof Error ? error.message : "Translation failed."
      };
    }
    if (seq !== lookupSeq || !slot.isConnected) {
      return;
    }
    if (!response.ok) {
      showTranslateButton(slot, response.error);
      return;
    }
    const translation = term.length > TRANSLATE_LIMIT ? `${response.data.translation} (first ${TRANSLATE_LIMIT} characters)` : response.data.translation;
    slot.replaceChildren(
      el("h3", void 0, "Google Translate"),
      el("p", "translation-result", translation)
    );
  }
  async function runSearch(term, seq) {
    const slot = region("lookup")?.querySelector('[data-region="dictionary"]');
    if (!slot) {
      return;
    }
    slot.replaceChildren(el("h3", void 0, "Dictionary"));
    slot.append(el("p", "muted", "Looking up\u2026"));
    const response = await request({ type: "search", term });
    if (seq !== lookupSeq || !region("lookup")?.querySelector('[data-region="dictionary"]')) {
      return;
    }
    slot.replaceChildren(el("h3", void 0, "Dictionary"));
    if (!response.ok) {
      slot.append(el("p", "muted", response.error));
      return;
    }
    if (response.data.cards.length === 0 && response.data.dictionaryCards.length === 0) {
      slot.append(el("p", "muted", `No dictionary results for \u201C${term}\u201D.`));
      return;
    }
    const owned = [...response.data.cards, ...state.cards];
    if (response.data.cards.length > 0) {
      slot.append(
        el("p", "sense", `In your collection (${response.data.cards.length})`)
      );
      for (const card2 of response.data.cards) {
        slot.append(
          renderCardLine(card2.kanji || card2.kana || card2.sense, card2.sense)
        );
      }
    }
    for (const entry of response.data.dictionaryCards) {
      slot.append(
        renderDictionaryEntry(
          entry,
          isHeadwordInCollection(
            {
              kanji: entry.kanji,
              kana: entry.kana,
              // The first sense is the one prefilled onto the card, matching the app.
              suru: entry.senses[0]?.isSuruVerb === true
            },
            owned
          )
        )
      );
    }
  }
  function renderCardLine(surface, sense) {
    const row = el("div", "entry");
    row.append(el("div", "word-surface", surface));
    row.append(el("div", "muted", sense));
    return row;
  }
  function plusIcon() {
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" d="M12 5v14M5 12h14"/></svg>';
  }
  function checkIcon() {
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" d="M5 12.5l4.5 4.5L19 7"/></svg>';
  }
  function collectedMark() {
    const mark = el("span", "add-btn collected");
    mark.title = "In your collection";
    mark.setAttribute("role", "img");
    mark.setAttribute("aria-label", "In your collection");
    mark.innerHTML = checkIcon();
    return mark;
  }
  function renderDictionaryEntry(entry, alreadyCollected) {
    const row = el("div", "entry");
    const surface = entry.kanji || entry.kana;
    const text = el("div", "entry-text");
    text.append(el("div", "word-surface", surface));
    if (entry.kana && entry.kanji) {
      text.append(el("div", "kana", entry.kana));
    }
    const gloss = entry.senses.flatMap((sense) => sense.senses).slice(0, 4).join("; ");
    if (gloss) {
      text.append(el("div", "muted", gloss));
    }
    row.append(text);
    if (alreadyCollected) {
      row.append(collectedMark());
      return row;
    }
    const add = el("button", "icon-btn add-btn");
    add.type = "button";
    add.dataset.action = "add-card";
    add.dataset.kanji = entry.kanji;
    add.dataset.kana = entry.kana;
    add.dataset.sense = gloss || surface;
    add.dataset.suru = entry.senses[0]?.isSuruVerb === true ? "true" : "false";
    add.title = "Add to collection";
    add.setAttribute("aria-label", "Add to collection");
    add.innerHTML = plusIcon();
    row.append(add);
    return row;
  }
  function field(label, name, value, multiline = false) {
    const wrap = el("label", void 0, label);
    const input = multiline ? el("textarea") : el("input");
    input.name = name;
    if (input instanceof HTMLTextAreaElement) {
      input.value = value;
    } else if (input instanceof HTMLInputElement) {
      input.value = value;
    }
    wrap.append(input);
    return wrap;
  }
  function openAddForm(button2) {
    const lookup = region("lookup");
    if (!lookup) {
      return;
    }
    lookup.querySelector('[data-region="add-form"]')?.remove();
    const prefill = cardPrefill(
      {
        kanji: button2.dataset.kanji ?? "",
        kana: button2.dataset.kana ?? "",
        sense: button2.dataset.sense ?? "",
        suru: button2.dataset.suru === "true"
      },
      lookup.dataset.sentence ?? ""
    );
    const form = el("form", "add-form");
    form.dataset.region = "add-form";
    form.dataset.kanji = button2.dataset.kanji ?? "";
    form.dataset.kana = button2.dataset.kana ?? "";
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      void saveAddForm(form);
    });
    form.append(el("h3", void 0, "Add to collection"));
    form.append(
      field("Kanji", "kanji", prefill.kanji),
      field("Kana", "kana", prefill.kana),
      field("Translation", "sense", prefill.sense),
      field("Note", "note", prefill.note, true)
    );
    const error = el("p", "form-error hidden");
    error.dataset.region = "add-error";
    const actions = el("div", "form-actions");
    const cancel = el("button", "btn quiet", "Cancel");
    cancel.type = "button";
    cancel.dataset.action = "cancel-add";
    const save = el("button", "btn primary", "Save");
    save.type = "submit";
    actions.append(cancel, save);
    form.append(error, actions);
    const back = lookup.querySelector('[data-action="show-words"]');
    if (back?.nextSibling) {
      lookup.insertBefore(form, back.nextSibling);
    } else {
      lookup.prepend(form);
    }
    form.querySelector("input")?.focus();
  }
  function formValue(form, name) {
    const fieldNode = form.elements.namedItem(name);
    if (fieldNode instanceof HTMLInputElement || fieldNode instanceof HTMLTextAreaElement) {
      return fieldNode.value.trim();
    }
    return "";
  }
  async function saveAddForm(form) {
    const sense = formValue(form, "sense");
    const kanji = formValue(form, "kanji");
    const kana = formValue(form, "kana");
    const note = formValue(form, "note");
    const error = form.querySelector('[data-region="add-error"]');
    const showError = (message) => {
      if (!error) {
        return;
      }
      error.textContent = message;
      error.classList.remove("hidden");
    };
    if (sense.length === 0) {
      showError("Add a meaning for the word.");
      return;
    }
    if (kanji.length === 0 && kana.length === 0) {
      showError("Fill in either the kanji or the kana.");
      return;
    }
    const save = form.querySelector('button[type="submit"]');
    if (save) {
      save.disabled = true;
    }
    const response = await request({
      type: "add-card",
      sense,
      kanji,
      kana,
      note
    });
    if (!response.ok) {
      if (save) {
        save.disabled = false;
      }
      showError(response.error);
      return;
    }
    const sourceKanji = form.dataset.kanji ?? "";
    const sourceKana = form.dataset.kana ?? "";
    const source = form.closest('[data-region="lookup"]')?.querySelector(
      `[data-action="add-card"][data-kanji="${CSS.escape(sourceKanji)}"][data-kana="${CSS.escape(sourceKana)}"]`
    );
    source?.replaceWith(collectedMark());
    form.remove();
    state.cards = [...state.cards, response.data];
    if (state.readingEnabled) {
      scan(state.cards);
    }
  }
  function focusHit(hit) {
    const range = document.createRange();
    range.setStart(hit.node, hit.start);
    range.setEnd(hit.node, hit.end);
    const rect = range.getBoundingClientRect();
    window.scrollBy({
      top: rect.top - window.innerHeight / 3,
      behavior: "smooth"
    });
    if (highlightsSupported()) {
      highlightRegistry()?.set("kotobaten-focus", new Highlight(range));
      window.setTimeout(
        () => highlightRegistry()?.delete("kotobaten-focus"),
        1400
      );
    }
  }
  function selectionPoint() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
      return null;
    }
    const text = selection.toString().replace(/\s+/g, " ").trim();
    if (!containsJapanese(text)) {
      return null;
    }
    const anchor = selection.anchorNode;
    if (anchor && anchor.getRootNode() === shadow) {
      return null;
    }
    const rect = selection.getRangeAt(0).getBoundingClientRect();
    return {
      text,
      sentence: text,
      x: rect.left,
      y: rect.bottom
    };
  }
  function scheduleDetect() {
    window.clearTimeout(scanTimer);
    scanTimer = window.setTimeout(() => {
      detect();
      if (state.readingEnabled && state.japanese && state.cards.length > 0 && !state.loading) {
        scan(state.cards);
        render();
      }
    }, 700);
  }
  async function claimAuthCallback() {
    if (location.hostname !== "web.kotobaten.app") {
      return;
    }
    const params = new URLSearchParams(location.search);
    const code = params.get("code");
    const state2 = params.get("state");
    const error = params.get("error_description") || params.get("error");
    if (!code && !error || !state2) {
      return;
    }
    let matches = false;
    try {
      const owned = await request({
        type: "owns-login-state",
        state: state2
      });
      matches = owned.ok && owned.data.matches;
    } catch {
      matches = false;
    }
    if (!matches) {
      return;
    }
    void chrome.runtime.sendMessage({
      type: "auth-callback",
      code,
      state: state2,
      error
    });
    for (const key of ["code", "state", "error", "error_description"]) {
      params.delete(key);
    }
    const query = params.toString();
    history.replaceState(
      null,
      "",
      `${location.pathname}${query ? `?${query}` : ""}${location.hash}`
    );
  }
  void claimAuthCallback();
  async function boot() {
    harvestWebSession();
    if (location.hostname === "web.kotobaten.app") {
      window.setInterval(harvestWebSession, 4e3);
      return;
    }
    if (ignoredHost() || !document.body) {
      return;
    }
    mount();
    const settings = await request({
      type: "get-settings"
    });
    const session = await request({
      type: "get-session"
    });
    if (settings.ok) {
      state.readingEnabled = settings.data.readingEnabled;
      state.preview = settings.data.previewSample;
      state.sidebarPinned = settings.data.sidebarPinned;
      if (state.sidebarPinned) {
        state.drawerOpen = true;
      }
    }
    if (session.ok) {
      state.signedIn = session.data.signedIn;
    }
    detect();
    if (state.readingEnabled && state.japanese) {
      await applyReading();
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "get-page-state") {
      sendResponse(pageState());
      return false;
    }
    if (message?.type === "reading-changed") {
      state.readingEnabled = message.enabled === true;
      state.drawerOpen = true;
      void applyReading();
      sendResponse(pageState());
      return false;
    }
    if (message?.type === "session-changed") {
      void request({
        type: "get-session"
      }).then((session) => {
        state.signedIn = session.ok && session.data.signedIn;
        if (state.signedIn && state.preview) {
          state.preview = false;
          void request({ type: "set-preview", enabled: false });
        }
        if (state.readingEnabled) {
          void applyReading();
        }
        const term = region("lookup")?.dataset.term ?? "";
        if (state.drawerOpen && state.panel === "lookup" && term.length > 0) {
          openLookup(term, region("lookup")?.dataset.sentence ?? "");
        } else {
          render();
        }
      });
      sendResponse(pageState());
      return false;
    }
    return false;
  });
  document.addEventListener(
    "mousemove",
    (event) => {
      if (!state.readingEnabled || state.hits.length === 0) {
        return;
      }
      const hit = hitAt(event.clientX, event.clientY);
      if (!hit) {
        hideTooltip();
        return;
      }
      showTooltip(hit, event.clientX, event.clientY);
    },
    { passive: true }
  );
  function eventFromSidebar(event) {
    return event.composedPath().some((node) => node === host || node === shadow);
  }
  document.addEventListener("mouseup", (event) => {
    if (!state.japanese || eventFromSidebar(event)) {
      return;
    }
    const selected = selectionPoint();
    if (selected) {
      hideTooltip();
      openLookup(selected.text, selected.sentence);
      return;
    }
    const hit = hitAt(event.clientX, event.clientY);
    if (hit && state.readingEnabled) {
      openLookup(hit.matchedText, hit.sentence);
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape" || !state.japanese) {
      return;
    }
    if (state.sortMenuOpen) {
      state.sortMenuOpen = false;
      render();
      return;
    }
    if (!state.drawerOpen) {
      return;
    }
    hideTooltip();
    state.drawerOpen = false;
    drawerDismissed = true;
    render();
  });
  var observer = new MutationObserver(() => scheduleDetect());
  function start() {
    void boot().then(() => {
      if (document.body && !ignoredHost()) {
        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
          characterData: true
        });
      }
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
