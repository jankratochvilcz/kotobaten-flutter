"use strict";
(() => {
  // src/messages.ts
  var API_BASE_URL_DEFAULT = "https://kotobaten-api.fly.dev";
  function normalizeApiBaseUrl(input) {
    const trimmed = input.trim();
    if (trimmed.length === 0) {
      throw new Error("API URL is required.");
    }
    let url;
    try {
      url = new URL(trimmed);
    } catch {
      throw new Error("API URL must be a full http or https address.");
    }
    if (url.protocol !== "https:" && url.protocol !== "http:") {
      throw new Error("API URL must start with https:// or http://.");
    }
    return url.origin;
  }

  // src/options/options.ts
  function send(message) {
    return chrome.runtime.sendMessage(message);
  }
  var apiInput = document.querySelector("#api");
  var tokenInput = document.querySelector("#token");
  var status = document.querySelector("#status");
  var save = document.querySelector("#save");
  var test = document.querySelector("#test");
  function setStatus(text) {
    if (status) {
      status.textContent = text;
    }
  }
  async function load() {
    const response = await send({ type: "get-settings" });
    if (!response.ok) {
      setStatus(response.error);
      return;
    }
    if (apiInput) {
      apiInput.value = response.data.apiBaseUrl || API_BASE_URL_DEFAULT;
    }
    if (tokenInput) {
      tokenInput.value = response.data.manualToken;
    }
  }
  save?.addEventListener("click", () => {
    void (async () => {
      try {
        const apiBaseUrl = normalizeApiBaseUrl(apiInput?.value ?? "");
        const originPattern = `${apiBaseUrl}/*`;
        const granted = await chrome.permissions.contains({
          origins: [originPattern]
        });
        if (!granted) {
          const allowed = await chrome.permissions.request({
            origins: [originPattern]
          });
          if (!allowed) {
            setStatus("Kotobaten needs permission to call that API address.");
            return;
          }
        }
        const response = await send({
          type: "save-settings",
          apiBaseUrl,
          manualToken: tokenInput?.value ?? ""
        });
        setStatus(response.ok ? "Saved." : response.error);
      } catch (error) {
        setStatus(
          error instanceof Error ? error.message : "Could not save settings."
        );
      }
    })();
  });
  test?.addEventListener("click", () => {
    void (async () => {
      setStatus("Contacting Kotobaten\u2026");
      const response = await send({ type: "test-connection" });
      setStatus(response.ok ? response.data : response.error);
    })();
  });
  void load();
})();
