"use strict";
(() => {
  // src/popup/popup.ts
  function send(message) {
    return chrome.runtime.sendMessage(message);
  }
  var page = document.querySelector("#page");
  var detail = document.querySelector("#detail");
  var reading = document.querySelector("#reading");
  var signIn = document.querySelector("#sign-in");
  var signOut = document.querySelector("#sign-out");
  var options = document.querySelector("#options");
  async function activePage() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id == null) {
      return null;
    }
    try {
      return await chrome.tabs.sendMessage(tab.id, {
        type: "get-page-state"
      });
    } catch {
      return null;
    }
  }
  function describe(session, current, settings) {
    if (!page || !detail || !reading || !signIn || !signOut) {
      return;
    }
    reading.checked = settings.readingEnabled;
    signIn.hidden = session.signedIn;
    signOut.hidden = !session.signedIn;
    if (session.loginError && !session.signedIn) {
      page.textContent = current?.japanese ? "Japanese page" : "Kotobaten";
      detail.textContent = session.loginError;
      return;
    }
    if (!current) {
      page.textContent = "Open a web page to use Kotobaten.";
      detail.textContent = session.signedIn ? session.email ?? (session.manual ? "Using a manual token." : "Signed in.") : "Sign in to underline your words and translate.";
      return;
    }
    page.textContent = current.japanese ? "Japanese page" : "This page is not Japanese";
    if (!current.japanese) {
      detail.textContent = "Reading help appears on pages written in Japanese, such as Nikkei.";
      return;
    }
    if (!settings.readingEnabled) {
      detail.textContent = session.signedIn ? "Turn on reading help to underline your words and translate a selection." : "Turn on reading help, then sign in so the underlines use your collection.";
      return;
    }
    if (current.loading) {
      detail.textContent = "Loading your collection\u2026";
      return;
    }
    if (current.preview) {
      detail.textContent = `Sample preview on this page (${current.matchCount} words). Sign in for your collection.`;
      return;
    }
    if (current.error) {
      detail.textContent = current.error;
      return;
    }
    const who = session.email ?? (session.manual ? "manual token" : "your account");
    detail.textContent = current.matchCount === 0 ? `Signed in (${who}). None of your words are in this page's text.` : `Signed in (${who}). ${current.matchCount} collection words on this page.`;
  }
  async function refresh() {
    const [settings, session, current] = await Promise.all([
      send({ type: "get-settings" }),
      send({ type: "get-session" }),
      activePage()
    ]);
    if (!settings.ok || !session.ok) {
      if (detail) {
        const failure = !settings.ok ? settings : session;
        detail.textContent = failure.ok ? "" : failure.error;
      }
      return;
    }
    describe(session.data, current, settings.data);
  }
  reading?.addEventListener("change", () => {
    void send({ type: "set-reading", enabled: reading.checked }).then(
      () => refresh()
    );
  });
  signIn?.addEventListener("click", () => {
    void send({ type: "sign-in" });
    window.close();
  });
  signOut?.addEventListener("click", () => {
    void send({ type: "sign-out" }).then(() => refresh());
  });
  options?.addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  void refresh();
})();
